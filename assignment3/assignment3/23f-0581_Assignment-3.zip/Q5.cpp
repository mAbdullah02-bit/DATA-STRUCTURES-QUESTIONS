//#include<iostream>
//#include"BSTq5.h"
//using namespace std;
//int main() {
//
//	BST t;
//	int x=0;
//	for (int i = 0; i < 9; i++)
//	{
//		cin >> x;
//		t.insert(x);
//
//	}
//	t.inorder();
//	int i = 0;
//	cout << "enter k: ";
//	cin >> x;
//	int* arr = new int[x + 1];
//	cout<<t.kthsmallest(t.root, i, x,arr)<<"     ";
//	
//	
//
//	return 0;
//}