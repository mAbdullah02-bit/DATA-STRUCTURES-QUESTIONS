//#include <iostream>
//#include"AVL.h" 
//using namespace std;
//int main() {
//    AvlTree tree;
//    int data;
//
//    for (int i = 0; i < 5; ++i) {
//        cout << "Enter Data: ";
//        cin >> data; 
//        tree.root = tree.insert(tree.root, data);
//        tree.inorder(tree.root);
//    }
//
//    cout << "Enter Data to delete: ";
//    cin >> data;
//    tree.root = tree.deletenode(tree.root, data);
//    tree.inorder(tree.root);
//
//    if (tree.isAVL(tree.root)) {
//        cout << "The tree is AVL balanced." << endl;
//    }
//    else {
//        cout << "The tree is not AVL balanced." << endl;
//    }
//
//    return 0;
//}
