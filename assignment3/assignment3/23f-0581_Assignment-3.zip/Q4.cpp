//#include<iostream>
//#include"BST+LL.h"
//
//using namespace std;
//
//int main() {
//
//	BST t;
//	int x;
//	for (int i = 0; i < 5; i++)
//	{
//		cin >> x;
//		t.insert(x);
//	}
//	t.inorder();
//	LinkedList l;
//	t.TreetoLL(t.root, l);
//
//	l.display();
//
//	return 0;
//
//}