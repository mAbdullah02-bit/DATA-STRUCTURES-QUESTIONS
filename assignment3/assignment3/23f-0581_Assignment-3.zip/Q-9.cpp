//#include <iostream>
//#include "BSTq9.h"
//
//using namespace std;
//
//int main() {
//    BST tree;
//    int arr[7]{1,2,4,5,3,6,7};
//    cout << "ARRAYY GIVEN: ";
//    for (int i = 0; i < 7; i++)
//    {
//        cout << arr[i] << " ";
//    }
//    cout << endl;
//    tree.root= tree.buildBST(arr);
//  
// 
//
//    cout << "Inorder: ";
//    tree.inorder();
//
//    cout << "Preorder: ";
//    tree.preorder();
//
//    cout << "Postorder: ";
//    tree.postorder();
//
//   
//
//    return 0;
//}
