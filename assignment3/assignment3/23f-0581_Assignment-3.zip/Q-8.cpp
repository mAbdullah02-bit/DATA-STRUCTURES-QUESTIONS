////#include "AVLq8.h"
////
////int main() {
////    AVL tree;
////    tree.insert(1, "Song_A");
////    tree.insert(5, "Song_B");
////    tree.insert(9, "Song_C");
////    tree.insert(2, "Song_D");
////    tree.insert(4, "Song_E");
////    tree.insert(6, "Song_F");
////    tree.insert(8, "Song_G");
////    tree.insert(3, "Song_H");
////    tree.insert(7, "Song_I");
////    tree.insert(9, "Song_J");
////    tree.insert(5, "Song_K");
////
////    cout << "Initial tree:" << endl;
////    tree.display();
////
////    cout << "\nPlaying Song_D and Song_E:" << endl;
////    tree.playSong(2, "Song_D");
////    tree.playSong(4, "Song_E");
////    tree.display();
//
//    return 0;
//}
