//#include "BSTClasses.h"
//#include <iostream>
//using namespace std;
//
//int main() {
//    BST tree;
//    int data;
//
// 
//    for (int i = 0; i < 5; i++) {
//        cout << "Enter data: ";
//        cin >> data;
//        tree.insert(data);
//    }
//
//   
//    cout << "Inorder: ";
//    tree.inorder();
//
//    cout << "Preorder: ";
//    tree.preorder();
//
//    cout << "Postorder: ";
//    tree.postorder();
//
//
//    cout << "Search for an element: ";
//    cin >> data;
//    tree.search(data);
//
//   
//    cout << "Delete an element: ";
//    cin >> data;
//    tree.deletenode(data);
//
//    
//    cout << "Inorder after deletion: ";
//    tree.inorder();
//
//    return 0;
//}
