//#include <iostream>
//#include "BST.h"
//
//using namespace std;
//
//int main() {
//    BST tree;
//    int arr[10]{1,2,3,4,5,6,7,8,9,10};
//
//    tree.root=tree.arraytoBST(arr, 0, 9);
// 
//
//    cout << "Inorder: ";
//    tree.inorder();
//
//    cout << "Preorder: ";
//    tree.preorder();
//
//    cout << "Postorder: ";
//    tree.postorder();
//
//   
//
//    return 0;
//}
